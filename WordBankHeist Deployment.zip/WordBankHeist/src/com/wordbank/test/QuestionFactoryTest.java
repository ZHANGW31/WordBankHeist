package com.wordbank.test;

import org.junit.Test;

import static org.junit.Assert.*;

public class QuestionFactoryTest {

    @Test
    public void getRandomNumber() {
    }

    @Test
    public void answerKey() {
    }

    @Test
    public void generateEasyQuestion() {
    }

    @Test
    public void generateMediumQuestion() {
    }

    @Test
    public void generateHardQuestion() {
    }

    @Test
    public void validateQuestion() {
    }

    @Test
    public void getQuestion() {
    }

    @Test
    public void setQuestion() {
    }

    @Test
    public void getLevel() {
    }
}