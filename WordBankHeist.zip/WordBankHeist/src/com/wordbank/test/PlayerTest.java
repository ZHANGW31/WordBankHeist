package com.wordbank.test;

import static org.junit.Assert.*;

public class PlayerTest {

    @org.junit.Test
    public void cashEarned() {
    }

    @org.junit.Test
    public void cashStolen() {
    }

    @org.junit.Test
    public void answerTheQuestion() {
    }

    @org.junit.Test
    public void isAnsweredAlready() {
    }

    @org.junit.Test
    public void cashOut() {
    }

    @org.junit.Test
    public void getName() {
    }

    @org.junit.Test
    public void setName() {
    }

    @org.junit.Test
    public void getCash() {
    }

    @org.junit.Test
    public void setCash() {
    }

    @org.junit.Test
    public void getCurrentLives() {
    }

    @org.junit.Test
    public void setCurrentLives() {
    }
}