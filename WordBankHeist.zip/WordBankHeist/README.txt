Double click on wordbankheist run.bat to run the program. 

Please expand the screen for the best user experience.

Thank you for playing!

From JavaNinjas - Rajan, Subash, Wei